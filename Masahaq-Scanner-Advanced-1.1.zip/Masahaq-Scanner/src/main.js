import { PDFDocument, rgb, degrees } from 'pdf-lib';
import * as pdfjsLib from 'pdfjs-dist';
import pdfWorker from 'pdfjs-dist/build/pdf.worker.min.mjs?url';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Share } from '@capacitor/share';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Capacitor } from '@capacitor/core';
import './style.css';

pdfjsLib.GlobalWorkerOptions.workerSrc = pdfWorker;

const $ = (id) => document.getElementById(id);
const STORAGE_KEY = 'masahaq_docs_v1';
let docs = loadDocs();
let currentId = null;
let selectedPage = 0;
let lang = localStorage.getItem('ms_lang') || 'ar';
let dark = localStorage.getItem('ms_dark') === '1';

const translations = {
  ar: {
    appName:'مسّاح المستندات',tagline:'حوّل أوراقك إلى ملفات رقمية',workspace:'مساحة العمل',
    hello:'كل مستنداتك في مكان واحد',intro:'صوّر، حسّن، ونظّم مستنداتك بسهولة.',
    scanCamera:'تصوير مستند',importImages:'استيراد صور',importPdf:'استيراد PDF',myDocs:'مستنداتي',
    searchPlaceholder:'ابحث باسم المستند...',emptyTitle:'لسه مفيش مستندات',
    emptyText:'ابدأ بتصوير ورقة أو استيراد صور من هاتفك.',editing:'تحرير المستند',
    addPage:'إضافة صفحة',filter:'تحسين الصورة',rotate:'تدوير',deletePage:'حذف الصفحة',
    saveDoc:'حفظ التغييرات',exportPdf:'تصدير PDF',exportJpg:'تصدير الصورة',deleteDoc:'حذف المستند',
    editorNote:'فلاتر معالجة محلية متقدمة، مع معاينة وإمكانية استعادة الأصل. النتائج تعتمد على جودة الصورة.',
    advancedFilters:'الفلاتر المتقدمة',original:'الأصل',auto:'تحسين تلقائي',documentBW:'مستند أبيض وأسود',gray:'رمادي',color:'ألوان محسّنة',shadow:'تقليل الظلال',hd:'وضوح HD',denoise:'تقليل التشويش',oldPhoto:'تحسين صورة باهتة',brightness:'السطوع',contrast:'التباين',sharpness:'الحدة',resetAdjust:'استعادة الأصل',applyAll:'تطبيق على كل الصفحات',previewBeforeAfter:'معاينة الصفحة بعد التحسين',filterTip:'المعالجة تتم على الجهاز ولا تستخدم OCR.',appliedAll:'تم تطبيق الإعداد على كل الصفحات',resetDone:'تمت استعادة الصورة الأصلية',
    home:'الرئيسية',scan:'مسح',settings:'الإعدادات',pages:'صفحات',rename:'إعادة تسمية',
    noPages:'لا توجد صفحات',saved:'تم حفظ المستند',deleted:'تم حذف المستند',choosePage:'اختر صفحة أولاً',
    titlePrompt:'اكتب اسم المستند',pdfImported:'تم استيراد صفحات PDF',pdfError:'تعذّر فتح ملف PDF',
    imageError:'تعذّر فتح الصورة',confirmDelete:'هل تريد حذف هذا المستند؟',settingsMsg:'الإعدادات: استخدم زر EN/ع لِتغيير اللغة وزر الهلال لتغيير المظهر.',
    filterDone:'تم تطبيق الفلتر',exportDone:'تم تجهيز الملف',needPages:'أضف صفحة واحدة على الأقل',
    pdfName:'مستند',imageName:'صورة',renameTitle:'اسم المستند'
  },
  en: {
    appName:'Document Scanner',tagline:'Turn paper into digital files',workspace:'WORKSPACE',
    hello:'All your documents in one place',intro:'Scan, enhance, and organize documents with ease.',
    scanCamera:'Scan document',importImages:'Import images',importPdf:'Import PDF',myDocs:'My documents',
    searchPlaceholder:'Search document names...',emptyTitle:'No documents yet',
    emptyText:'Scan a page or import images from your phone.',editing:'Edit document',
    addPage:'Add page',filter:'Enhance image',rotate:'Rotate',deletePage:'Delete page',
    saveDoc:'Save changes',exportPdf:'Export PDF',exportJpg:'Export image',deleteDoc:'Delete document',
    editorNote:'Advanced local image processing, preview, and original restore. Results depend on image quality.',
    advancedFilters:'Advanced filters',original:'Original',auto:'Auto enhance',documentBW:'Document B&W',gray:'Grayscale',color:'Enhanced color',shadow:'Reduce shadows',hd:'HD clarity',denoise:'Reduce noise',oldPhoto:'Fade recovery',brightness:'Brightness',contrast:'Contrast',sharpness:'Sharpness',resetAdjust:'Restore original',applyAll:'Apply to all pages',previewBeforeAfter:'Enhanced page preview',filterTip:'Processing runs on-device and does not use OCR.',appliedAll:'Settings applied to all pages',resetDone:'Original image restored',
    home:'Home',scan:'Scan',settings:'Settings',pages:'pages',rename:'Rename',
    noPages:'No pages',saved:'Document saved',deleted:'Document deleted',choosePage:'Select a page first',
    titlePrompt:'Enter document name',pdfImported:'PDF pages imported',pdfError:'Could not open PDF',
    imageError:'Could not open image',confirmDelete:'Delete this document?',settingsMsg:'Settings: use EN/ع to change language and the moon button to switch theme.',
    filterDone:'Filter applied',exportDone:'File prepared',needPages:'Add at least one page',
    pdfName:'Document',imageName:'Image',renameTitle:'Document name'
  }
};
const t = (key) => translations[lang][key] || key;

function loadDocs(){ try{return JSON.parse(localStorage.getItem(STORAGE_KEY)||'[]')}catch{return []} }
function persist(){ try{localStorage.setItem(STORAGE_KEY,JSON.stringify(docs));}catch{toast(lang==='ar'?'مساحة التخزين ممتلئة. صدّر الملفات ثم احذف بعض المستندات.':'Storage is full. Export files and remove some documents.');} renderDocs(); }
function toast(message){ const el=$('toast');el.textContent=message;el.classList.add('show');setTimeout(()=>el.classList.remove('show'),2600); }
function uid(){return `${Date.now()}_${Math.random().toString(36).slice(2,8)}`;}
function dataUrlToBytes(dataUrl){return Uint8Array.from(atob(dataUrl.split(',')[1]),c=>c.charCodeAt(0));}
function readFile(file){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(r.result);r.onerror=reject;r.readAsDataURL(file);});}
function imageFromUrl(url){return new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=reject;img.src=url;});}
function canvasData(url, filter='none', rotation=0){
  return imageFromUrl(url).then(img=>{
    const sideways=Math.abs(rotation%180)===90,c=document.createElement('canvas');c.width=sideways?img.height:img.width;c.height=sideways?img.width:img.height;
    const ctx=c.getContext('2d',{willReadFrequently:true});ctx.translate(c.width/2,c.height/2);ctx.rotate(rotation*Math.PI/180);ctx.drawImage(img,-img.width/2,-img.height/2);
    const cfg=typeof filter==='object'&&filter?filter:{preset:({none:'original',bw:'documentBW',gray:'gray',bright:'auto'}[filter]||filter)};const preset=cfg.preset||'original';
    let frame=ctx.getImageData(0,0,c.width,c.height),d=frame.data;const clamp=v=>Math.max(0,Math.min(255,v));
    // Estimate broad lighting variation from a small image and compensate gently.
    if(['shadow','auto','hd'].includes(preset)){
      const small=document.createElement('canvas'),sw=Math.max(1,Math.min(140,c.width)),sh=Math.max(1,Math.round(c.height*sw/c.width));small.width=sw;small.height=sh;small.getContext('2d').drawImage(c,0,0,sw,sh);
      const bg=document.createElement('canvas');bg.width=c.width;bg.height=c.height;const bc=bg.getContext('2d');bc.imageSmoothingEnabled=true;bc.drawImage(small,0,0,c.width,c.height);const bd=bc.getImageData(0,0,c.width,c.height).data;
      for(let i=0;i<d.length;i+=4){const lum=.299*bd[i]+.587*bd[i+1]+.114*bd[i+2];const target=preset==='shadow'?224:preset==='hd'?218:220;const f=Math.max(.78,Math.min(preset==='shadow'?1.65:1.4,target/Math.max(45,lum)));for(let k=0;k<3;k++)d[i+k]=clamp(d[i+k]*f);}
    }
    if(preset==='documentBW')for(let i=0;i<d.length;i+=4){const y=.299*d[i]+.587*d[i+1]+.114*d[i+2],v=y>158?255:0;d[i]=d[i+1]=d[i+2]=v;}
    if(preset==='gray')for(let i=0;i<d.length;i+=4){const y=.299*d[i]+.587*d[i+1]+.114*d[i+2];d[i]=d[i+1]=d[i+2]=y;}
    if(preset==='color')for(let i=0;i<d.length;i+=4){const y=.299*d[i]+.587*d[i+1]+.114*d[i+2];for(let k=0;k<3;k++)d[i+k]=clamp(y+(d[i+k]-y)*1.2);}
    if(preset==='oldPhoto')for(let i=0;i<d.length;i+=4)for(let k=0;k<3;k++)d[i+k]=clamp((d[i+k]-128)*1.16+138);
    if(preset==='denoise'){
      const temp=document.createElement('canvas');temp.width=c.width;temp.height=c.height;const tc=temp.getContext('2d');tc.filter='blur(1px)';tc.drawImage(c,0,0);const blur=tc.getImageData(0,0,c.width,c.height).data;
      for(let i=0;i<d.length;i+=4)for(let k=0;k<3;k++)d[i+k]=clamp(d[i+k]*.58+blur[i+k]*.42);
    }
    const brightness=Number(cfg.brightness||0),contrast=Number(cfg.contrast||0),sharpness=Number(cfg.sharpness||0);
    if(brightness||contrast){const f=(259*(contrast+255))/(255*(259-contrast));for(let i=0;i<d.length;i+=4)for(let k=0;k<3;k++)d[i+k]=clamp(f*(d[i+k]-128)+128+brightness);}
    if(sharpness>0||preset==='hd'){
      const src=new Uint8ClampedArray(d),amount=sharpness>0?Math.min(1,sharpness/100):.3;
      for(let y=1;y<c.height-1;y++)for(let x=1;x<c.width-1;x++){const i=(y*c.width+x)*4;for(let k=0;k<3;k++){const avg=(src[i-4+k]+src[i+4+k]+src[i-c.width*4+k]+src[i+c.width*4+k])/4;d[i+k]=clamp(src[i+k]+(src[i+k]-avg)*amount);}}
    }
    ctx.putImageData(frame,0,0);return c.toDataURL('image/jpeg',.94);
  });
}
function applyLanguage(){
  document.documentElement.lang=lang;document.documentElement.dir=lang==='ar'?'rtl':'ltr';
  document.querySelectorAll('[data-i18n]').forEach(el=>{const key=el.dataset.i18n;if(translations[lang][key])el.textContent=t(key)});
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el=>el.placeholder=t(el.dataset.i18nPlaceholder));
  $('langBtn').textContent=lang==='ar'?'EN':'ع';
  $('themeBtn').textContent=dark?'☀':'☾';
  document.body.classList.toggle('dark',dark);
  renderDocs(); if(currentId)renderEditor();
}
function renderDocs(){
  const term=$('searchInput').value.trim().toLowerCase();
  const list=docs.filter(d=>d.title.toLowerCase().includes(term));
  $('docCount').textContent=String(list.length);
  $('emptyState').classList.toggle('hidden',list.length>0);
  $('documents').innerHTML='';
  list.sort((a,b)=>b.updated-a.updated).forEach(doc=>{
    const card=document.createElement('article');card.className='doc-card';
    const thumb=document.createElement('div');thumb.className='doc-thumb';
    if(doc.pages[0]){const im=document.createElement('img');im.src=doc.pages[0].image;im.alt='';thumb.append(im)}else thumb.textContent='PDF';
    const info=document.createElement('div');info.className='doc-info';
    const title=document.createElement('strong');title.textContent=doc.title;
    const meta=document.createElement('small');meta.textContent=`${doc.pages.length} ${t('pages')} · ${new Date(doc.updated).toLocaleDateString(lang==='ar'?'ar-EG':'en-US')}`;
    info.append(title,meta);
    const actions=document.createElement('div');actions.className='doc-actions';
    const open=document.createElement('button');open.className='icon-btn';open.textContent='↗';open.title='Open';open.onclick=()=>openEditor(doc.id);
    const more=document.createElement('button');more.className='icon-btn';more.textContent='⋯';more.title=t('rename');more.onclick=()=>renameDoc(doc.id);
    actions.append(open,more);card.append(thumb,info,actions);$('documents').append(card);
  });
}
function newDoc(pages=[],title=''){
  const doc={id:uid(),title:title||`${t('pdfName')} ${new Date().toLocaleString(lang==='ar'?'ar-EG':'en-US')}`,pages:pages.map(image=>({id:uid(),image,filter:'none',rotation:0})),updated:Date.now()};
  docs.push(doc);persist();openEditor(doc.id);
}
function openEditor(id){currentId=id;selectedPage=0;$('editor').classList.remove('hidden');renderEditor();$('editor').scrollIntoView({behavior:'smooth',block:'start'});}
function activeDoc(){return docs.find(d=>d.id===currentId)}
async function renderEditor(){
  const doc=activeDoc();if(!doc)return;
  $('docTitle').value=doc.title;$('pages').innerHTML='';
  doc.pages.forEach((p,i)=>{
    const item=document.createElement('button');item.className='page-thumb'+(i===selectedPage?' selected':'');item.onclick=()=>{selectedPage=i;renderEditor()};
    const im=document.createElement('img');im.src=p.image;im.alt=`Page ${i+1}`;
    const label=document.createElement('span');label.textContent=`${i+1}`;item.append(im,label);$('pages').append(item);
  });
  if(!doc.pages.length){const empty=document.createElement('p');empty.className='muted';empty.textContent=t('noPages');$('pages').append(empty)}
  const page=doc.pages[selectedPage],preview=$('scanPreview');
  if(page){try{preview.src=await canvasData(page.image,page.enhancement||page.filter,page.rotation||0)}catch{preview.src=page.image}preview.classList.remove('hidden');const cfg=page.enhancement||{};['brightness','contrast','sharpness'].forEach(k=>{const el=$(k+'Slider');if(el)el.value=cfg[k]||0;const v=$(k+'Value');if(v)v.textContent=String(cfg[k]||0)})}else{preview.removeAttribute('src');preview.classList.add('hidden')}
}
function closeEditor(){currentId=null;$('editor').classList.add('hidden');renderDocs()}
async function addImages(files){
  const urls=[];
  for(const file of files){if(file.type.startsWith('image/')){try{urls.push(await readFile(file))}catch{}}}
  if(!urls.length)return;
  if(currentId){const d=activeDoc();d.pages.push(...urls.map(image=>({id:uid(),image,filter:'none',rotation:0})));d.updated=Date.now();selectedPage=d.pages.length-1;persist();renderEditor();}
  else newDoc(urls);
}
async function captureCamera(){
  try{
    if(Capacitor.isNativePlatform()){
      const photo=await Camera.getPhoto({quality:92,allowEditing:false,resultType:CameraResultType.DataUrl,source:CameraSource.Camera});
      if(photo.dataUrl)addImagesFromUrls([photo.dataUrl]);
    }else $('cameraPicker').click();
  }catch(e){if(!Capacitor.isNativePlatform())$('cameraPicker').click();else toast(String(e.message||e));}
}
function addImagesFromUrls(urls){
  if(currentId){const d=activeDoc();d.pages.push(...urls.map(image=>({id:uid(),image,filter:'none',rotation:0})));d.updated=Date.now();selectedPage=d.pages.length-1;persist();renderEditor();}
  else newDoc(urls);
}
async function importPdf(file){
  try{
    const bytes=await file.arrayBuffer();
    const pdf=await pdfjsLib.getDocument({data:bytes}).promise;
    const urls=[];
    for(let i=1;i<=pdf.numPages;i++){
      const page=await pdf.getPage(i);const viewport=page.getViewport({scale:1.5});
      const canvas=document.createElement('canvas');canvas.width=viewport.width;canvas.height=viewport.height;
      await page.render({canvasContext:canvas.getContext('2d'),viewport}).promise;
      urls.push(canvas.toDataURL('image/jpeg',.9));
    }
    newDoc(urls,file.name.replace(/\.pdf$/i,'')||t('pdfName'));toast(t('pdfImported'));
  }catch(e){console.error(e);toast(t('pdfError'))}
}
async function saveDoc(){
  const d=activeDoc();if(!d)return;
  d.title=$('docTitle').value.trim()||t('pdfName');d.updated=Date.now();persist();toast(t('saved'));
}
async function exportPdf(){
  const d=activeDoc();if(!d)return;if(!d.pages.length){toast(t('needPages'));return}
  try{
    const pdf=await PDFDocument.create();
    for(const p of d.pages){
      let url=await canvasData(p.image,p.enhancement||p.filter,p.rotation);
      const bytes=dataUrlToBytes(url);const jpg=await pdf.embedJpg(bytes);
      const page=pdf.addPage([jpg.width,jpg.height]);page.drawImage(jpg,{x:0,y:0,width:jpg.width,height:jpg.height});
    }
    const bytes=await pdf.save();await saveOrDownload(bytes,`${safeName(d.title)}.pdf`,'application/pdf');toast(t('exportDone'));
  }catch(e){console.error(e);toast('PDF export failed')}
}
async function saveOrDownload(bytes,name,mime){
  const blob=new Blob([bytes],{type:mime});
  if(Capacitor.isNativePlatform()){
    const base64=await blobToBase64(blob);
    const saved=await Filesystem.writeFile({path:name,data:base64,directory:Directory.Documents,recursive:true});
    try{await Share.share({title:name,text:name,url:saved.uri,dialogTitle:lang==='ar'?'مشاركة الملف':'Share file'});}catch{}
  }else{
    const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(url),1500);
  }
}
function blobToBase64(blob){return new Promise((resolve,reject)=>{const r=new FileReader();r.onload=()=>resolve(String(r.result).split(',')[1]);r.onerror=reject;r.readAsDataURL(blob)})}
function safeName(s){return s.replace(/[\\/:*?"<>|]/g,'_').slice(0,80)||'document'}
async function exportImage(){
  const d=activeDoc();const p=d?.pages[selectedPage];if(!p){toast(t('choosePage'));return}
  const url=await canvasData(p.image,p.enhancement||p.filter,p.rotation);const blob=await (await fetch(url)).blob();
  if(Capacitor.isNativePlatform()){
    await saveOrDownload(new Uint8Array(await blob.arrayBuffer()),`${safeName(d.title)}_${selectedPage+1}.jpg`,'image/jpeg');
  }else{const a=document.createElement('a');a.href=url;a.download=`${safeName(d.title)}_${selectedPage+1}.jpg`;a.click()}
}
function renameDoc(id){const d=docs.find(x=>x.id===id);if(!d)return;const value=prompt(t('renameTitle'),d.title);if(value?.trim()){d.title=value.trim();d.updated=Date.now();persist()}}
async function applyPreset(preset,all=false){
  const d=activeDoc(),p=d?.pages[selectedPage];if(!p){toast(t('choosePage'));return}
  const cfg={preset,brightness:0,contrast:0,sharpness:preset==='hd'?35:0};
  if(all)d.pages.forEach(page=>{page.enhancement={...cfg};page.filter='none'});else{p.enhancement=cfg;p.filter='none'}
  d.updated=Date.now();persist();await renderEditor();toast(all?t('appliedAll'):t('filterDone'));
}
async function applyFilter(){
  const options=[['original',t('original')],['auto',t('auto')],['documentBW',t('documentBW')],['gray',t('gray')],['color',t('color')],['shadow',t('shadow')],['hd',t('hd')],['denoise',t('denoise')],['oldPhoto',t('oldPhoto')]];
  const answer=prompt((lang==='ar'?'اكتب رقم الفلتر:\n':'Enter filter number:\n')+options.map((o,i)=>`${i+1}. ${o[1]}`).join('\n'),'2');const n=Number(answer);if(!Number.isInteger(n)||n<1||n>options.length)return;await applyPreset(options[n-1][0]);
}
async function updateAdjustment(key,value){
  const d=activeDoc(),p=d?.pages[selectedPage];if(!p)return;const cfg={...(p.enhancement||{preset:'original',brightness:0,contrast:0,sharpness:0}),[key]:Number(value)};p.enhancement=cfg;p.filter='none';$(key+'Value').textContent=String(value);
  try{$('scanPreview').src=await canvasData(p.image,cfg,p.rotation||0)}catch{}
}
async function resetEnhancement(){const p=activeDoc()?.pages[selectedPage];if(!p)return;delete p.enhancement;p.filter='none';await renderEditor();toast(t('resetDone'))}
async function applyEnhancementToAll(){const d=activeDoc(),p=d?.pages[selectedPage];if(!d||!p)return;const cfg={...(p.enhancement||{preset:'original',brightness:0,contrast:0,sharpness:0})};d.pages.forEach(page=>{page.enhancement={...cfg};page.filter='none'});d.updated=Date.now();persist();await renderEditor();toast(t('appliedAll'))}
function rotatePage(){const p=activeDoc()?.pages[selectedPage];if(!p){toast(t('choosePage'));return}p.rotation=(p.rotation+90)%360;renderEditor()}
function deletePage(){const d=activeDoc();if(!d?.pages[selectedPage])return;d.pages.splice(selectedPage,1);selectedPage=Math.max(0,selectedPage-1);d.updated=Date.now();persist();renderEditor()}
function deleteDoc(){if(!currentId)return;if(!confirm(t('confirmDelete')))return;docs=docs.filter(d=>d.id!==currentId);currentId=null;persist();closeEditor();toast(t('deleted'))}

$('cameraBtn').onclick=captureCamera;
$('navScan').onclick=captureCamera;
$('importImagesBtn').onclick=()=>$('imagePicker').click();
$('addPageBtn').onclick=()=>$('imagePicker').click();
$('importPdfBtn').onclick=()=>$('pdfPicker').click();
$('imagePicker').onchange=async e=>{await addImages([...e.target.files]);e.target.value=''};
$('cameraPicker').onchange=async e=>{await addImages([...e.target.files]);e.target.value=''};
$('pdfPicker').onchange=async e=>{if(e.target.files[0])await importPdf(e.target.files[0]);e.target.value=''};
$('closeEditor').onclick=closeEditor;
$('saveDocBtn').onclick=saveDoc;
$('exportPdfBtn').onclick=exportPdf;
$('exportJpgBtn').onclick=exportImage;
$('filterBtn').onclick=applyFilter;
$('presetButtons').querySelectorAll('[data-preset]').forEach(btn=>btn.onclick=()=>applyPreset(btn.dataset.preset));
$('resetEnhancementBtn').onclick=resetEnhancement;$('applyAllBtn').onclick=applyEnhancementToAll;
['brightness','contrast','sharpness'].forEach(k=>{$(k+'Slider').oninput=e=>updateAdjustment(k,e.target.value)});
$('rotateBtn').onclick=rotatePage;
$('deletePageBtn').onclick=deletePage;
$('deleteDocBtn').onclick=deleteDoc;
$('docTitle').onchange=()=>{const d=activeDoc();if(d){d.title=$('docTitle').value.trim()||t('pdfName');d.updated=Date.now();persist()}};
$('searchInput').oninput=renderDocs;
$('langBtn').onclick=()=>{lang=lang==='ar'?'en':'ar';localStorage.setItem('ms_lang',lang);applyLanguage()};
$('themeBtn').onclick=()=>{dark=!dark;localStorage.setItem('ms_dark',dark?'1':'0');applyLanguage()};
$('navSettings').onclick=()=>toast(t('settingsMsg'));
applyLanguage();
